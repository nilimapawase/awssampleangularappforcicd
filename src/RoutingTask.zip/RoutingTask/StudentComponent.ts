import { Component } from "@angular/core";

@Component({
    selector:'app-root',
    template:"<h2>Student Page"
})

export class StudentClass{

}