import { CommonModule } from "@angular/common";
import { Component } from "@angular/core";
import { RouterModule } from "@angular/router";

@Component({
    selector:'app-root',
    templateUrl:"Common.html",
    imports: [RouterModule]
})

export class CommonClass{
    
    // isLogin:boolean=false;
    // username:any="";

    // ngDoCheck(){

    //     let user = localStorage.getItem("username");

    //     if(user){
    //         this.isLogin=true;
    //         this.username=user;
    //     }
    //     else{
    //         this.isLogin=false;
    //     }
    // }

    // constructor(){
    //     this.CheckLogin();
    // }

    // CheckLogin()
    // {
    //     let user = localStorage.getItem("username");

    //     if(user)
    //     {
    //         this.isLogin = true;
    //         this.username = user;
    //     }
    //     else
    //     {
    //         this.isLogin = false;
    //         this.username = "";
    //     }
    // }

    get isLogin()
    {
        return localStorage.getItem("username") != null;
    }

    get username()
    {
        return localStorage.getItem("username");
    }
}